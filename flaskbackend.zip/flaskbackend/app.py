from flask import Flask
from flask_cors import CORS
from config import Config
from database import db
from routes.auth import auth_bp
from routes.profile import profile_bp
from routes.feedback import feedback_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    CORS(app, resources={r"/api/*": {"origins": Config.ALLOWED_ORIGINS}})

    db.init_app(app)

    app.register_blueprint(auth_bp,     url_prefix="/api/auth")
    app.register_blueprint(profile_bp,  url_prefix="/api/profile")
    app.register_blueprint(feedback_bp, url_prefix="/api/feedback")

    with app.app_context():
        db.create_all()  # creates tables if they don't exist

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
